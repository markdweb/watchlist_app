package com.cheese.watchlist.ui.components

import androidx.compose.material3.MaterialTheme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Sell
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.cheese.watchlist.navigation.Screen

data class BottomNavDestination(val screen: Screen, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

val bottomNavDestinations = listOf(
    BottomNavDestination(Screen.Watchlist, "Watchlist", Icons.Outlined.Bookmark),
    BottomNavDestination(Screen.Genres, "Genres", Icons.Outlined.Sell),
    BottomNavDestination(Screen.Settings, "Settings", Icons.Outlined.Settings)
)

@Composable
fun WatchlistBottomNavBar(currentRoute: String?, onNavigate: (Screen) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        bottomNavDestinations.forEach { dest ->
            val selected = currentRoute == dest.screen.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(dest.screen) },
                icon = { Icon(dest.icon, contentDescription = dest.label) },
                label = { Text(dest.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                )
            )
        }
    }
}
