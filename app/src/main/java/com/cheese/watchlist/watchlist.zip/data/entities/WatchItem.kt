package com.cheese.watchlist.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class WatchType { MOVIE, SERIES }

enum class WatchStatus(val label: String) {
    TO_WATCH("To Watch"),
    WATCHING("Watching"),
    WATCHED("Watched"),
    DROPPED("Dropped")
}

@Entity(tableName = "watch_items")
data class WatchItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val status: WatchStatus = WatchStatus.TO_WATCH,
    val type: WatchType = WatchType.MOVIE,
    val genre: String = "",
    val whereToWatch: String = "",
    val url: String = "",
    val rating: Int = 0,
    val favorite: Boolean = false,
    val comments: String = "",
    val yearDate: String = "",
    val totalEpisodes: Int = 0,
    val currentEpisode: Int = 0,
    val season: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
