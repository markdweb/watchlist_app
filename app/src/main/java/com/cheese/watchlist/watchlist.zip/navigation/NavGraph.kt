package com.cheese.watchlist.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cheese.watchlist.data.entities.WatchType
import com.cheese.watchlist.ui.components.WatchlistBottomNavBar
import com.cheese.watchlist.ui.screens.AddEditScreen
import com.cheese.watchlist.ui.screens.GenresScreen
import com.cheese.watchlist.ui.screens.ManageSourcesScreen
import com.cheese.watchlist.ui.screens.PcManagerScreen
import com.cheese.watchlist.ui.screens.SettingsScreen
import com.cheese.watchlist.ui.screens.WatchlistScreen
import com.cheese.watchlist.viewmodel.WatchlistViewModel

private val bottomBarRoutes = setOf(Screen.Watchlist.route, Screen.Genres.route, Screen.Settings.route)

@Composable
fun WatchlistNavGraph(
    viewModel: WatchlistViewModel,
    darkTheme: Boolean,
    onToggleDarkTheme: (Boolean) -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomBarRoutes) {
                WatchlistBottomNavBar(currentRoute = currentRoute) { screen ->
                    navController.navigate(screen.route) {
                        popUpTo(Screen.Watchlist.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Watchlist.route,
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            composable(Screen.Watchlist.route) {
                WatchlistScreen(
                    viewModel = viewModel,
                    onAddType = { type ->
                        navController.navigate(Screen.AddEdit.createRoute(itemId = null, type = type.name))
                    },
                    onOpenItem = { id ->
                        navController.navigate(Screen.AddEdit.createRoute(itemId = id))
                    }
                )
            }
            composable(Screen.Genres.route) {
                GenresScreen(viewModel = viewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = viewModel,
                    darkTheme = darkTheme,
                    onToggleDarkTheme = onToggleDarkTheme,
                    onManageGenres = { navController.navigate(Screen.Genres.route) },
                    onManageSources = { navController.navigate(Screen.ManageSources.route) },
                    onPcManager = { navController.navigate(Screen.PcManager.route) }
                )
            }
            composable(Screen.PcManager.route) {
                PcManagerScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.ManageSources.route) {
                ManageSourcesScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
            }
            composable(
                route = Screen.AddEdit.route,
                arguments = listOf(
                    navArgument("itemId") { type = NavType.LongType; defaultValue = -1L },
                    navArgument("type") { type = NavType.StringType; defaultValue = "" }
                )
            ) { entry ->
                val itemId = entry.arguments?.getLong("itemId") ?: -1L
                val typeArg = entry.arguments?.getString("type") ?: ""
                val initialType = if (typeArg == WatchType.SERIES.name) WatchType.SERIES else WatchType.MOVIE
                AddEditScreen(
                    viewModel = viewModel,
                    itemId = if (itemId > 0) itemId else null,
                    initialType = initialType,
                    onDone = { navController.popBackStack() }
                )
            }
        }
    }
}
