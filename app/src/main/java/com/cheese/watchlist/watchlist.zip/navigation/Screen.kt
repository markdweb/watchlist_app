package com.cheese.watchlist.navigation

sealed class Screen(val route: String) {
    data object Watchlist : Screen("watchlist")
    data object Genres : Screen("genres")
    data object Settings : Screen("settings")
    data object ManageSources : Screen("manage_sources")
    data object PcManager : Screen("pc_manager")
    data object AddEdit : Screen("add_edit?itemId={itemId}&type={type}") {
        fun createRoute(itemId: Long? = null, type: String? = null): String {
            val id = itemId ?: -1L
            val t = type ?: ""
            return "add_edit?itemId=$id&type=$t"
        }
    }
}
