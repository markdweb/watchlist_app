package com.cheese.watchlist.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.cheese.watchlist.data.dao.GenreDao
import com.cheese.watchlist.data.dao.SourceDao
import com.cheese.watchlist.data.dao.WatchItemDao
import com.cheese.watchlist.data.entities.Converters
import com.cheese.watchlist.data.entities.GenreEntity
import com.cheese.watchlist.data.entities.SourceEntity
import com.cheese.watchlist.data.entities.WatchItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [WatchItem::class, GenreEntity::class, SourceEntity::class],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun watchItemDao(): WatchItemDao
    abstract fun genreDao(): GenreDao
    abstract fun sourceDao(): SourceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val DEFAULT_GENRES = listOf(
            "Anime", "Comedy", "Adventure", "Fantasy", "Horror",
            "Thriller", "Romance", "Mystery", "Action"
        )

        val DEFAULT_SOURCES = listOf(
            "Cinemas", "Netflix", "Hurawatch", "Moviebox", "9anime"
        )

        /**
         * v1 -> v2: adds season tracking to watch_items, cleans up any duplicate
         * genres/sources that existed before duplicate-prevention was added, and
         * enforces uniqueness on genre/source names going forward.
         */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE watch_items ADD COLUMN season INTEGER NOT NULL DEFAULT 1")

                // Keep only the earliest row per case-insensitive name, drop the rest.
                db.execSQL("DELETE FROM genres WHERE id NOT IN (SELECT MIN(id) FROM genres GROUP BY name COLLATE NOCASE)")
                db.execSQL("DELETE FROM sources WHERE id NOT IN (SELECT MIN(id) FROM sources GROUP BY name COLLATE NOCASE)")

                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_genres_name ON genres(name)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_sources_name ON sources(name)")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "watchlist.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = INSTANCE
                                database?.genreDao()?.insertAll(DEFAULT_GENRES.map { GenreEntity(name = it) })
                                database?.sourceDao()?.insertAll(DEFAULT_SOURCES.map { SourceEntity(name = it) })
                            }
                        }
                    }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
