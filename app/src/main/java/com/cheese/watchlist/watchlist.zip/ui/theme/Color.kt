package com.cheese.watchlist.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundLight = Color(0xFFF8F7FC)
val SurfaceWhite = Color(0xFFFFFFFF)
val PrimaryAccent = Color(0xFF4F6FF5)
val PrimaryAccentDark = Color(0xFF3B57D6)
val BorderSubtle = Color(0xFFE7E5F0)
val TextPrimary = Color(0xFF1C1C28)
val TextSecondary = Color(0xFF8B8A9A)
val StarYellow = Color(0xFFFFC94A)

// Status colors — kept subtle, not overly bright
val StatusToWatch = Color(0xFF8B8A9A)
val StatusWatching = Color(0xFF4F6FF5)
val StatusWatched = Color(0xFF3DBE7E)
val StatusDropped = Color(0xFFE0616B)

// Dark theme palette
val BackgroundDark = Color(0xFF15151C)
val SurfaceDark = Color(0xFF1F1F29)
val BorderSubtleDark = Color(0xFF2E2E3A)
val TextPrimaryDark = Color(0xFFECECF2)
val TextSecondaryDark = Color(0xFFA0A0AE)
