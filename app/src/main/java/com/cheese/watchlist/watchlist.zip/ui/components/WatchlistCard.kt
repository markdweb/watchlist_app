package com.cheese.watchlist.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.foundation.clickable
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.cheese.watchlist.data.entities.WatchItem
import com.cheese.watchlist.data.entities.WatchType
import com.cheese.watchlist.ui.theme.StarYellow

@Composable
fun WatchlistCard(
    item: WatchItem,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onOpenUrl: () -> Unit,
    onToggleFavorite: () -> Unit,
    onIncrementEpisode: () -> Unit,
    onDecrementEpisode: () -> Unit,
    modifier: Modifier = Modifier,
    selectionMode: Boolean = false,
    isSelected: Boolean = false,
    onToggleSelect: () -> Unit = {},
    onLongPress: () -> Unit = {}
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                else MaterialTheme.colorScheme.surface
            )
            .border(
                1.dp,
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                RoundedCornerShape(20.dp)
            )
            .combinedClickable(
                onClick = { if (selectionMode) onToggleSelect() else onClick() },
                onLongClick = onLongPress
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            // Type icon, replaced with a selection checkmark while in selection mode
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                if (selectionMode) {
                    Icon(
                        imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                        contentDescription = if (isSelected) "Selected" else "Not selected",
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Icon(
                        imageVector = if (item.type == WatchType.MOVIE) Icons.Outlined.Movie else Icons.Outlined.Tv,
                        contentDescription = item.type.name,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            androidx.compose.foundation.layout.Spacer(Modifier.size(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (!selectionMode) {
                        IconButton(onClick = onToggleFavorite, modifier = Modifier.size(28.dp)) {
                            Icon(
                                imageVector = if (item.favorite) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                contentDescription = "Favorite",
                                tint = if (item.favorite) StarYellow else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Text(
                    text = "${if (item.type == WatchType.MOVIE) "Movie" else "Series"} • ${item.status.label}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = statusColor(item.status)
                )

                if (item.genre.isNotBlank()) {
                    Text(
                        text = item.genre,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (item.rating > 0) {
                    androidx.compose.foundation.layout.Spacer(Modifier.size(4.dp))
                    RatingStars(rating = item.rating, starSize = 14.dp)
                }

                if (item.type == WatchType.SERIES && item.totalEpisodes > 0) {
                    androidx.compose.foundation.layout.Spacer(Modifier.size(10.dp))
                    Text(
                        text = "Season ${item.season}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    androidx.compose.foundation.layout.Spacer(Modifier.size(4.dp))
                    EpisodeProgress(
                        currentEpisode = item.currentEpisode,
                        totalEpisodes = item.totalEpisodes,
                        showControls = !selectionMode,
                        onIncrement = onIncrementEpisode,
                        onDecrement = onDecrementEpisode
                    )
                }

                if (item.url.isNotBlank()) {
                    androidx.compose.foundation.layout.Spacer(Modifier.size(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = if (!selectionMode) Modifier.clickable(onClick = onOpenUrl) else Modifier
                    ) {
                        Icon(
                            Icons.Outlined.Link,
                            contentDescription = "Open link",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        androidx.compose.foundation.layout.Spacer(Modifier.size(4.dp))
                        Text(
                            text = item.url,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (!selectionMode) {
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
