package com.cheese.watchlist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cheese.watchlist.data.database.AppDatabase
import com.cheese.watchlist.data.preferences.OnboardingPreferences
import com.cheese.watchlist.data.preferences.ThemePreferences
import com.cheese.watchlist.data.repository.WatchlistRepository
import com.cheese.watchlist.navigation.WatchlistNavGraph
import com.cheese.watchlist.ui.screens.FirstGreetingScreen
import com.cheese.watchlist.ui.screens.OnboardingScreen
import com.cheese.watchlist.ui.screens.SplashScreen
import com.cheese.watchlist.ui.theme.WatchlistTheme
import com.cheese.watchlist.viewmodel.WatchlistViewModel
import com.cheese.watchlist.viewmodel.WatchlistViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Note: edge-to-edge is intentionally NOT enabled here. Enabling it requires
        // careful per-screen window-insets handling (status bar, nav bar) throughout
        // the app; without that it causes content to be padded incorrectly (double
        // top padding, cramped bottom nav touch targets). Leaving it off lets the
        // system reserve status/navigation bar space automatically and correctly.

        val database = AppDatabase.getInstance(applicationContext)
        val repository = WatchlistRepository(
            watchItemDao = database.watchItemDao(),
            genreDao = database.genreDao(),
            sourceDao = database.sourceDao()
        )

        setContent {
            WatchlistApp(repository)
        }
    }
}

private sealed class LaunchStep {
    data object Splash : LaunchStep()
    data object Onboarding : LaunchStep()
    data class FirstGreeting(val name: String) : LaunchStep()
    data object Main : LaunchStep()
}

@Composable
fun WatchlistApp(repository: WatchlistRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var darkTheme by remember { mutableStateOf(ThemePreferences.isDarkMode(context)) }

    var step by remember { mutableStateOf<LaunchStep>(LaunchStep.Splash) }
    var onboardingAlreadyComplete by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) {
        onboardingAlreadyComplete = OnboardingPreferences.isOnboardingComplete(context)
    }

    WatchlistTheme(darkTheme = darkTheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            AnimatedContent(
                targetState = step,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "launch_flow"
            ) { currentStep ->
                when (currentStep) {
                    is LaunchStep.Splash -> {
                        SplashScreen(
                            onFinished = {
                                step = if (onboardingAlreadyComplete == true) {
                                    LaunchStep.Main
                                } else {
                                    LaunchStep.Onboarding
                                }
                            }
                        )
                    }
                    is LaunchStep.Onboarding -> {
                        OnboardingScreen(
                            onComplete = { name ->
                                scope.launch {
                                    OnboardingPreferences.setUserName(context, name)
                                    OnboardingPreferences.setOnboardingComplete(context, true)
                                }
                                step = LaunchStep.FirstGreeting(name)
                            }
                        )
                    }
                    is LaunchStep.FirstGreeting -> {
                        FirstGreetingScreen(
                            name = currentStep.name,
                            onFinished = { step = LaunchStep.Main }
                        )
                    }
                    is LaunchStep.Main -> {
                        val viewModel: WatchlistViewModel = viewModel(
                            factory = WatchlistViewModelFactory(repository)
                        )
                        WatchlistNavGraph(
                            viewModel = viewModel,
                            darkTheme = darkTheme,
                            onToggleDarkTheme = { enabled ->
                                darkTheme = enabled
                                ThemePreferences.setDarkMode(context, enabled)
                            }
                        )
                    }
                }
            }
        }
    }
}
